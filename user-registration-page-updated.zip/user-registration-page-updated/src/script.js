
$(function() {  
    $("#trigger").click(function() {  
        $(".pulse_off").toggleClass("pulse_on");  
    });  
});

$(".toggle_btn").click(function () {
$(".login_button_big").toggle();
$(".login_button_big2").toggle();
});

